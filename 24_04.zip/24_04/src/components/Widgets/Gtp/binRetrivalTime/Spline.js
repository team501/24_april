import React, {Component} from 'react';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component
import './graph.css';


class LineChart extends Component {
	
	constructor(props) {
		super(props);
		
		this.state = { 
				tooltip: false,
				value: '',
				dataSet: 0,
				index: 0,
				x: 0,
				y: 0,
				color: ''
					 };
	}
	
	getInitialState() {
		return {
			tooltip: false,
			value: '',
			dataSet: 0,
			index: 0,
			x: 0,
			y: 0,
			color: ''
		}
	}


	componentWillReceiveProps() {		
		this.setState({ updating: true }, this.endUpdate)		
	}


	endUpdate() {
		setTimeout(() =>
		this.setState({ updating: false }), 300)
	}

	showTooltip(point, dataSetIndex, index) {
		this.setState({
			updating: false,
			tooltip: true,
			value: point[2],
			dataSet: dataSetIndex,
			index: index,
			x: point[0],
			y: point[1],
			color: point[3]
		})		
	}


	hideTooltip() {
		this.setState(this.getInitialState())
	}


	render() {
		var { data, lines, area, dots, stroke, radius, grid, axis } = this.props,
		width = this.props.width || 400,
		height = this.props.height || width * (9 / 16),
		colors = this.props.colors || ['#aaa', '#888'],
		labels = this.props.labels || [],
		hideLabels = this.props.hideLabels || false,
		size = data[0].length - 1,
		maxValue = 0,
		heightRatio = 1,
		padding = this.props.padding || 50,
		dataSet = [],
		grid = typeof grid !== 'undefined' ? grid : true,
				stroke = stroke || 1,
				radius = radius || 3


				// Calculate the maxValue
				dataSet = data.forEach(pts => {
					var max = Math.max.apply(null, pts)		
					maxValue =	max > maxValue ? max : maxValue	
				})	


				// Y ratio
				if (maxValue === 0) {
					heightRatio = 1
				} else {
					heightRatio = height / maxValue
				}

		// Calculate the coordinates
		dataSet = data.map((pts, di) =>
		pts.map((pt, pi) => [
			~~((width / size) * pi + padding) + .5, // x
			~~((heightRatio) * (maxValue - pt) + padding) + .5, // y
			pt, // value
			colors[di % colors.length] // color
			]			
		))



		return (
				<span className="LineChart" style={{ width:(width + padding * 2) + 'px'}}>
				<svg xmlns="http://www.w3.org/2000/svg"
					width={ (width + padding * 2) + 'px' }
				height={ (height + 2*padding) + 'px' }
				viewBox={ '0 0 ' + (width + 2*padding) + ' ' + (height + 2*padding) }
				>
				{ grid ?
						<g>
				<XAxis maxValue={ maxValue } padding={ padding } width={ width } height={ height } />
				<YAxis axis={ axis } padding={ padding } width={ width } height={ height } />
				<Rect data={ data } axis={ axis } padding={ padding } width={ width } height={ height } targetvalue={this.props.targetvalue} currentposition={this.props.currentposition} isColorBlind={this.props.isColorBlind}/>
				</g>
				: null }
				{ dataSet.map((p, pi) =>
				<g key={ pi }>
				<Curve
				points={ p }
				dataSetIndex={ pi }
				lines={ lines }
				area={ area }
				width={ width }
				height={ height }
				padding={ padding }
				color={ colors[pi % colors.length] }
				updating={ this.state.updating }
				stroke={ stroke }
				/>

				<Points hideLabels={ hideLabels } dots={ dots } label={ labels[pi] } points={ p } dataSetIndex={ pi } showTooltip={ this.showTooltip } hideTooltip={ this.hideTooltip } stroke={ stroke } radius={ radius } />

				</g>
				)}

				</svg>

				{ this.state.tooltip ?
						<Tooltip
						value={ this.state.value }
				label={ labels[this.state.dataSet] }
				x={ this.state.x }
				y={ this.state.y - 15 }
				color={ this.state.color }
				/>
				: null }
				</span>
		)
	}
}




class Tooltip extends Component {
	render() {
		var { value, label, x, y, color } = this.props,
		style

		style = {
				left: ~~x,
				top: ~~y			
		}

		return (
				<span className="LineChart--tooltip" style={ style }>
				<b style={{ color: color }}>{ label }</b>
				<i>{ value }</i>
				</span>
		)
	}
}




class XAxis extends Component{
	render () {
		var padding = this.props.padding,
		lines = [0, 1, 2,3,4,5,6,7,8,9,10,11,12],
		segment = this.props.height / 12,
		maxValue = ~~(this.props.maxValue / 4),
		target = 12
		return (
				<g>
				{ lines.map((l, li) => {
					var y = ~~(l * segment + padding) + .5
					return (
							<g>
							{l === target &&( <line x1={ padding } y1={ y }
													x2={ this.props.width + padding } y2={ y }
													stroke="#000"
													strokeWidth="3px"
								/>)}
								</g>
					)})}

				</g>
		)
	}
}




class YAxis extends Component {
	render () {
		var padding = this.props.padding,
		lines = [0, 1, 2,3,4,5,6,7,8,9,10,11,12],
		segment = this.props.width / 12,
		height = this.props.height + padding,
		axis = this.props.axis,
		target = 6
		
		return (
				<g>
				{ lines.map((l, li) => {
					var x = ~~(li * segment + padding) + .5
					return (
							<g>
							{l === target &&( <line x1={ x } y1={ padding }
							  x2={ x } y2={ height }
							  stroke="#000" strokeWidth="3px"
							/> )}
									  <text className="LineChart--axis" x={ x } y={ height + 15 } textAnchor="middle">
									  	{ axis[li % axis.length] }
									  </text>
							</g>
					)
				})}

				</g>
		)
	}
}




class Points extends Component {
	render () {
		var { points, dataSetIndex, showTooltip, hideTooltip, radius, stroke, label, dots, hideLabels } = this.props,
		lastPoint = points[points.length - 1],
		color = lastPoint[3],
		x = lastPoint[0],
		y = lastPoint[1]


		return (
				<g>
				{ dots === true ?
						points.map((p, pi) =>
						<Point
						point={ p }
						dataSetIndex={ dataSetIndex }
						showTooltip={ showTooltip }
						hideTooltip={ hideTooltip }
						stroke={ stroke }
						radius={ radius }
						index={ pi }
						key={ pi }
						/>)
						: null }

				{ hideLabels !== true ?
						<text className="LineChart--label" x={ x + 5 } y={ y + 2 } fill={ color }>{ label }</text>
						: null }
				</g>
						)
	}
}


class Curve extends Component {
	render () {
		var { points, dataSetIndex, width, height, padding, lines, area, dots, color, stroke, updating } = this.props,
		path = [], areaPath = [],	style, fn

		fn = lines === true ? 'L' : 'R'
			height += padding		
			style = {	pointerEvents: 'none' }

		if (updating === true) {
			style['opacity'] = 0
			style['transition'] = 'none'
		}

		path = points.map((p, pi) => (pi === 0  ? '' : (pi === 1 ? fn : '')) + p[0] + ',' + p[1]);
		path = 'M' + path.join(' ')		

		if (lines !== true) {
			path = parsePath(path, height).join(' ')
		}


		if (area === true) {
			areaPath = path.replace('M', 'L')
			areaPath = 'M' + padding + ',' + height + areaPath
			areaPath += 'L' + (width + padding) + ',' + height
		}

		return (
				<g style={ style }>
				{ area === true ? <path d={ areaPath } fill={ color } fillOpacity=".05" /> : null  }
					<path d={ path } fill="none" stroke={ color } strokeWidth={ stroke } />				
					</g>
		)
	}
}




class Point extends Component {
	mouseEnter() {
		this.props.showTooltip(this.props.point, this.props.dataSetIndex, this.props.index)
	}


	mouseLeave() {
		this.props.hideTooltip()
	}


	render() {
		var { point, stroke, radius } = this.props,
		x = point[0],
		y = point[1],
		color = point[3]

		return <circle
		cx={ x } cy={ y }
		r={ radius } fill={ color }
		strokeWidth={ stroke } stroke={ '#ffffff' }
		onMouseEnter={ this.mouseEnter } onMouseLeave={ this.mouseLeave } />
	}
}

class Rect extends Component{
	
	render() {
		let x_axis = 250;
		let y_axis = 50;
		let color = "#000";
		var padding = this.props.padding,
		lines = [0, 1, 2,3,4,5,6,7,8,9,10,11,12],
		segment = this.props.width / 12,
		height = this.props.height + padding,
		axis = this.props.axis,
		target = this.props.targetvalue,
		currentposition = this.props.currentposition,
		width = this.props.width || 400,
		maxValue = 0,
		heightRatio = 1
		
		console.log("Target Value: "+target);
		y_axis = padding
		let x_currentposition =0;
		lines.map((l, li) => {
			var x = ~~(li * segment + padding) + .5
			if(l === target) {
				console.log("X of Segment x"+ x)
				console.log("Y of Segment y1: "+ padding)
				console.log("X of Segment y2: "+ height)
				x_axis = x;
			}
		
			if(l === currentposition) {
				console.log("X of Segment x"+ x)
				console.log("Y of Segment y1: "+ padding)
				console.log("X of Segment y2: "+ height)
				x_currentposition = x;
			}
		})
		
		// Calculate the maxValue
		dataSet = this.props.data.forEach(pts => {
			var max = Math.max.apply(null, pts)		
			maxValue =	max > maxValue ? max : maxValue	
		})	


		// Y ratio
		if (maxValue === 0) {
			heightRatio = 1
		} else {
			heightRatio = height / maxValue
		}
		
		console.log(this.props.data[0])
		let avg = this.props.data[0].reduce((a,b) => a + b) / (this.props.data[0].length)
		
		var closest = this.props.data[0].reduce(function(prev, curr) {
		  return (Math.abs(curr - avg) < Math.abs(prev - avg) ? curr : prev);
		});
		let dataPointTemp = this.props.data[0];
		let closestIndex = dataPointTemp.indexOf(closest)
		let arr = [...dataPointTemp]
		if( avg > closest) {
			 closestIndex = closestIndex + 1;
		} 
			
		arr.splice(closestIndex, 0, avg);
		let size = arr.length - 1
		// Calculate the coordinates
		let dataSet = arr.map((pt, pi) => ([
			~~((width / size) * pi + padding) + .5, // x
			~~((heightRatio) * (maxValue - pt) + padding) + .5, // y
			pt // value
			]			
		));
		
		//let target_x = dataSet[closestIndex][0]
		//let target_y = dataSet[closestIndex][1]
		let target_width = 0;
		
		
		if(currentposition > target)
		{
		target_width = x_currentposition - x_axis 
		color ="#FF0000";	
		}else{
		target_width =  x_axis - x_currentposition
		x_axis = x_currentposition
		color ="#008000";
		}
	
		const { isColorBlind } = this.props;
		if(isColorBlind){	
		color ="#87871F";	
		}
		return (<g>
					<rect x={x_axis} y={y_axis} width={ target_width } height={height - padding} fill= {color} opacity="0.5" strokeWidth={0}  stroke = "rgb(0,0,0)" />
					
					<rect x={x_axis-20} y={y_axis + 30} width="50" height="25" rx="5" ry="5" fill= {color}  strokeWidth={0} />
					<text x={x_axis-20} y={y_axis + 47} class="small" filter="red" fill="white">&nbsp;+10 sec</text>
				</g>);
	}
}


function getRandomInt(min, max) {
			return Math.floor(Math.random() * (max - min)) + min;
		}


		// Catmull-Rom to Bezier found here: https://jsdo.it/ynakajima/catmullrom2bezier
		// Whoever wrote this is AWESOME! Thank you!
		function parsePath(d, maxHeight) {
			var pathArray = [], lastX = '', lastY = ''

				if ( -1 != d.search(/[rR]/) ) {
					// no need to redraw the path if no Catmull-Rom segments are found

					// split path into constituent segments
					var pathSplit = d.split(/([A-Za-z])/);
					for (var i = 0, iLen = pathSplit.length; iLen > i; i++) {
						var segment = pathSplit[i];

						// make command code lower case, for easier matching
						// NOTE: this code assumes absolution coordinates, and doesn't account for relative command coordinates
						var command = segment.toLowerCase()
						if ( -1 != segment.search(/[A-Za-z]/) ) {
							var val = "";
							if ( "z" != command ) {
								i++;
								val = pathSplit[ i ].replace(/\s+$/, '');
							}

							if ( "r" == command ) {
								// "R" and "r" are the a Catmull-Rom spline segment

								var points = lastX + "," + lastY + " " + val;

								// convert Catmull-Rom spline to Bézier curves
								var beziers = catmullRom2bezier( points, maxHeight );
								//insert replacement curves back into array of path segments
								pathArray.push( beziers );
							} else {
								// rejoin the command code and the numerical values, place in array of path segments
								pathArray.push( segment + val );

								// find last x,y points, for feeding into Catmull-Rom conversion algorithm
								if ( "h" == command ) {
									lastX = val;
								} else if ( "v" == command ) {
									lastY = val;
								} else if ( "z" != command ) {
									var c = val.split(/[,\s]/);
									lastY = c.pop();
									lastX = c.pop();
								}
							}
						}
					}
					// recombine path segments and set new path description in DOM
				}

			return pathArray
		}



		function catmullRom2bezier( points, maxHeight ) {
			var crp = points.split(/[,\s]/);

			var d = "";
			for (var i = 0, iLen = crp.length; iLen - 2 > i; i+=2) {
				var p = [];
				if ( 0 == i ) {
					p.push( {x: parseFloat(crp[ i ]), y: parseFloat(crp[ i + 1 ])} );
					p.push( {x: parseFloat(crp[ i ]), y: parseFloat(crp[ i + 1 ])} );
					p.push( {x: parseFloat(crp[ i + 2 ]), y: parseFloat(crp[ i + 3 ])} );
					p.push( {x: parseFloat(crp[ i + 4 ]), y: parseFloat(crp[ i + 5 ])} );
				} else if ( iLen - 4 == i ) {
					p.push( {x: parseFloat(crp[ i - 2 ]), y: parseFloat(crp[ i - 1 ])} );
					p.push( {x: parseFloat(crp[ i ]), y: parseFloat(crp[ i + 1 ])} );
					p.push( {x: parseFloat(crp[ i + 2 ]), y: parseFloat(crp[ i + 3 ])} );
					p.push( {x: parseFloat(crp[ i + 2 ]), y: parseFloat(crp[ i + 3 ])} );
				} else {
					p.push( {x: parseFloat(crp[ i - 2 ]), y: parseFloat(crp[ i - 1 ])} );
					p.push( {x: parseFloat(crp[ i ]), y: parseFloat(crp[ i + 1 ])} );
					p.push( {x: parseFloat(crp[ i + 2 ]), y: parseFloat(crp[ i + 3 ])} );
					p.push( {x: parseFloat(crp[ i + 4 ]), y: parseFloat(crp[ i + 5 ])} );
				}

				// Catmull-Rom to Cubic Bezier conversion matrix 
				//    0       1       0       0
				//  -1/6      1      1/6      0
				//    0      1/6      1     -1/6
				//    0       0       1       0

				var bp = [];
				bp.push( { x: p[1].x,  y: p[1].y } );
				bp.push( { x: ((-p[0].x + 6*p[1].x + p[2].x) / 6), y: ((-p[0].y + 6*p[1].y + p[2].y) / 6)} );
				bp.push( { x: ((p[1].x + 6*p[2].x - p[3].x) / 6),  y: ((p[1].y + 6*p[2].y - p[3].y) / 6) } );
				bp.push( { x: p[2].x,  y: p[2].y } );

				bp = bp.map(_ => {
					if (_.y > maxHeight) {
						_.y = maxHeight
					}

					return _
				})

				d += "C" + bp[1].x + "," + bp[1].y + " " + bp[2].x + "," + bp[2].y + " " + bp[3].x + "," + bp[3].y + " ";
			}

			return d;
		}




class Spline extends Component{		
	render() {
		let opt = this.props.opt
		return (
				<div>
					<LineChart {...opt}
							   area={ true }
							   stroke={ 2 }
							   radius={ 2 }
							   grid={ true }
							   hideLabels={ true }
							   width={ 250 }
							   height={ 150 }
							   dots={ true }
							   target={this.props.opt.targetvalue}
							   currentposition={this.props.opt.currentposition}
							   isColorBlind={this.props.isColorBlind}
					/>
					
					{/*<LineChart {...opt} dots={ true } lines={ true } />*/}
					{/*<LineChart {...opt} width={ 600 } height={ 50 } stroke={ 2 } radius={ 6 } dots={ true } grid={ true } hideLabels={ true } />*/}
				</div>
		)
	}
}


//export default Spline;

const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(Spline));