
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component
//chart
//chart config


// helpers
import { hexToRgbA } from 'Helpers/helpers';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';

import Spinner from 'Util/Spinner';


class Pbar extends Component {



	render() {
	
	const { isColorBlind } = this.props;
		let inductPercentage = 80 ;
			let lag = 10;
			let success = 10;
			let rem =  100 - lag;
			let successPerc = inductPercentage;
			let pointerPerc = inductPercentage - 10 ;
			let lagPerc = inductPercentage + 10;
			let timePerc = inductPercentage + 5;
			//console.log("widthPerc .... ");
			//console.log(lagPerc);
			//console.log(timePerc);
			const customWidth = {
				width: inductPercentage+'%'
			}
			const customWidthGreen = {
				width: successPerc+'%'
			}
			const customWdthPntr = {
				width: pointerPerc+'%'
			}
			const customWidthRed = {
				width: lagPerc +'%',
				//color: linear-gradient(to right,  white rem+'%', red lag+'%'),
			}
			const customWidthTime = {
				width: timePerc +'%'
			}
			let bluecolorop = "#0685e3";
			let greencolorp = "#03b819";
			if(isColorBlind){	
			bluecolorop = "#12a8f5";
			greencolorp ="#828275";
		}
			return (

					<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full opcontainer" heading="" key="" fullBlock >
						<Grid item xs={12} sm={12}>
							<div className="opProgressbar">
									<div className="customBar station-status-textblack" style={customWdthPntr} >{inductPercentage}%</div>	
									<div className="customBar" style={customWdthPntr} >&#x2BC6;</div>	
									
									 <ProgressBar>
				                  		<ProgressBar  style={{height:'7px',backgroundColor: bluecolorop}} now={inductPercentage} />
				                  	</ProgressBar>
									
							</div>
						</Grid>
		                <Grid item xs={12} sm={12}>
							<div>
									<div className="customBarTime station-status-textblack opgreen" style={{customWidthTime, color: greencolorp}} >00:00:00 <span className="deltaHrs">hrs</span></div>	
									<div className="customBarGreen" style={{backgroundColor: greencolorp}} >&nbsp;</div>	
																			
									 <ProgressBar>
				                  		<ProgressBar  style={{height:'5px',backgroundColor: bluecolorop}} now={inductPercentage} />
				                  	</ProgressBar>
									
							</div>
						</Grid>
						 
		     
		        </RctCollapsibleCard>
			);
			
			
		}
		
	}


	const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	//console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(Pbar));
//export default Pbar;

