// routes
import Dashboard from 'Routes/dashboard';

export default [
	{
		path: 'dashboard',
		component: Dashboard
	}
]